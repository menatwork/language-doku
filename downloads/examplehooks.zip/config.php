<?php 

// $GLOBALS['TL_HOOKS']['language2fileManipulateSql'][] = array([CLASS], [FUNCTION]);
$GLOBALS['TL_HOOKS']['language2fileManipulateSql'][] = array('test', 'runTest');