<?php

class Test
{
	public function __construct()
	{

	}

	public function runTest(&$strSql, &$arrParameters, $strFunction, $strTable)
	{
		if($strTable == 'tl_content' && $strFunction == 'getPageLanguage')
		{
			$strSql .= ' AND 1 = 1';
		}
	}
}